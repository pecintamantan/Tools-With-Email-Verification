<section class="inner-page">
      <div class="container">

  

        


  <div class="jumbotron">
    <form action="" method="post">
      <div class="form-group">
        <input class="form-control input-lg" name ="domain" type="text" placeholder="<?php if(isset($_POST['submit'])) { echo($_POST['domain']); }else{echo("www.zone-ryy.xyz");} ?>" required><br>
            <button type="submit" name="submit" class="btn btn-primary is-loading">Lookup DNS</button>
      </div>
    </form>
  </div>

  <div class="row marketing">

    <?php

      if(isset($_POST['submit']))
          {
            $domain_regex = '/[a-z\d][a-z\-\d\.]+[a-z\d]/i';
            $domain = $_POST['domain'];
            $dns_a = dns_get_record($domain, DNS_A);
            $dns_ns = dns_get_record($domain, DNS_NS);
            $dns_mx = dns_get_record($domain, DNS_MX);
            $dns_soa = dns_get_record($domain, DNS_SOA);
            $dns_txt = dns_get_record($domain, DNS_TXT);
            $dns_aaaa = dns_get_record($domain, DNS_AAAA);
            $dns_all = dns_get_record($domain, DNS_ALL);

    ?>

    <table class="table table-striped table-bordered table-responsive">
      <thead class="bg-primary">
          <td class="text-center">Record</td>
          <td class="text-center">Class</td>
          <td class="text-center">TTL</td>
          <td>Details for <?php echo($_POST['domain']); ?></td>
      </thead>
      <tr>
        <td class="vert-align text-center"><span class="label label-primary"><?php echo($dns_a[0]['type']); ?></span></td>
        <td class="vert-align text-center"><?php echo($dns_a[0]['class']); ?></td>
        <td class="vert-align text-center"><?php echo($dns_a[0]['ttl']); ?></td>
        <td>
          <?php 
          foreach($dns_a as $value)
            {
              ?>  
                  <?php
                    echo($value['ip']);
                  ?>
                
              <?php } ?>
        </td>
      </tr>
      <?php $result_aaaa = empty($dns_aaaa); if($result_aaaa != null){ ?>
      <tr class = "warning">
        <td class="vert-align text-center">AAAA</td>
        <td class="vert-align text-center">/</td>
        <td class="vert-align text-center">/</td>
        <td>No AAAA record for this server (IPV6)</td>
      </tr>
      <?php } else { ?>
      <tr>
        <td class="vert-align text-center"><span class="label label-info"><?php echo($dns_aaaa[0]['type']); ?><?php echo($result_aaaa); ?></span></td>
        <td class="vert-align text-center"><?php echo($dns_aaaa[0]['class']); ?></td>
        <td class="vert-align text-center"><?php echo($dns_aaaa[0]['ttl']); ?></td>
        <td>
          <?php 
          foreach($dns_aaaa as $value)
            {
              ?>
                <?php  echo($value['ipv6']); ?>
              
              <?php } ?>
        </td>
      </tr>
      <?php } ?>
      <tr>
        <td class="vert-align text-center"><span class="label label-success"><?php echo($dns_ns[0]['type']); ?></span></td>
        <td class="vert-align text-center"><?php echo($dns_ns[0]['class']); ?></td>
        <td class="vert-align text-center"><?php echo($dns_ns[0]['ttl']); ?></td>
        <td>
          <?php 
          foreach($dns_ns as $value)
            {
              ?>
                <?php  echo($value['target']); ?>
                (<?php echo(gethostbyname($value['target'])) ?>)
              
              <?php } ?>
        </td>
      </tr>
      <tr>
        <td class="vert-align text-center"><span class="label label-danger"><?php echo($dns_mx[0]['type']); ?></span></td>
        <td class="vert-align text-center"><?php echo($dns_mx[0]['class']); ?></td>
        <td class="vert-align text-center"><?php echo($dns_mx[0]['ttl']); ?></td>
        <td>
          <?php 
          foreach($dns_mx as $value)
            {
              ?>
                [<?php  echo($value['pri']); ?>] 
                <?php  echo($value['target']); ?>
                (<?php echo(gethostbyname($value['target'])) ?>)
              
              <?php } ?>
        </td>
      </tr>
      <tr>
        <td class="vert-align text-center"><span class="label label-warning"><?php echo($dns_soa[0]['type']); ?></span></td>
        <td class="vert-align text-center"><?php echo($dns_soa[0]['class']); ?></td>
        <td class="vert-align text-center"><?php echo($dns_soa[0]['ttl']); ?></td>
        <td>
            Email : <?php $email = explode(".", $dns_soa[0]['rname']); echo($email[0].'@'.$email[1].'.'.$email[2]); ?>
            Serial : <?php echo($dns_soa[0]['serial']); ?>
            Refresh : <?php echo($dns_soa[0]['refresh']); ?>
            Retry : <?php echo($dns_soa[0]['retry']); ?>
            Expire : <?php echo($dns_soa[0]['expire']); ?>
            Minimum TTL : <?php echo($dns_soa[0]['minimum-ttl']); ?>
        </td>
      </tr>
      <tr>
        <td class="vert-align text-center"><span class="label label-default"><?php echo($dns_txt[0]['type']); ?></span></td>
        <td class="vert-align text-center"><?php echo($dns_txt[0]['class']); ?></td>
        <td class="vert-align text-center"><?php echo($dns_txt[0]['ttl']); ?></td>
        <td>
            <?php echo($dns_txt[0]['txt']); ?>
        </td>
      </tr>
      <tr>
        <td colspan="4" class="vert-align text-center">
          <?php $uniqid = uniqid(); file_put_contents('export/dns_export_'.$domain.'_'.$uniqid.'.txt', var_export($dns_all, TRUE)); $link = $domain.'_'.$uniqid ?>
          <a href="export/dns_export_<?php echo($link); ?>.txt" class="btn btn-info" role="button" target="_blank" download>Download records (.txt)</a>
        </td>
      </tr>
    </table>

  </div>

<?php
          }
?>




  
  </div>
    </section>