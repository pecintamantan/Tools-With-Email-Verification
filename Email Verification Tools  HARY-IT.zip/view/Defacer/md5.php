

    <section class="inner-page">
      <div class="container">

  <form method="post" name="pageform"
action="" onsubmit="return validate(this);">
<div class="form-group">
<textarea class="form-control" name="mbut" placeholder="Masukin Disini"/></textarea>
<br>
<input class="btn btn-primary is-loading" name="mbuttt" type="submit" value=" Encrypt Md5 " id="button"/>
</div>
</form>
<?php
if(isset($_POST['mbuttt'])) { 
$hash = explode("\r\n",$_POST['mbut']);
foreach($hash as $pass) { 
$md5 = md5($pass);
echo "<nobr><font color='#FF2816'>".$pass."</font> = <font color='#FF2816'>".$md5."</font></nobr><br>";
}
echo "<br/><br/>";
}
?>







  
  </div>
    </section>
    <center>