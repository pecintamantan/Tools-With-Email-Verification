
    <section class="inner-page">
      <div class="container">

  



<div class="jumbotron">
  <form action="" method="POST">
  <div class="form-group">
  <input class="form-control" type="text" value="66.70.176.59" name="target"><br>
  <button class="btn btn-primary is-loading" name="submit">Scan</button>
  </div>
  </form>
<?php
error_reporting(0);
set_time_limit(0);

if (isset($_POST['submit'])) {
$target = htmlspecialchars($_POST['target']);
$host = $target;
  $ports = array(21, 22, 23,25,53, 80, 81, 110, 143, 443, 3306, 3389);

    foreach ($ports as $port)
    {
        $connection = @fsockopen($host, $port);

        if (is_resource($connection))
        {
            echo '<br><font color=lime>' . $host . ':' . $port . ' ' . '(' . getservbyport($port, 'tcp') . ') Terbuka.' . "</font>";

            fclose($connection);
        }

        else
        {
            echo '<br><font color=red>' . $host . ':' . $port . ' Tidak Merespon.' . "</font>";
        }
    }
}
?>





  
  </div>
    </section>