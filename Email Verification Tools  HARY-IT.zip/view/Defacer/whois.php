
    <section class="inner-page">
      <div class="container">

  

       
            <?php
               @set_time_limit(0);
               @error_reporting(0);
               function sws_domain_info($site)
               {
               $getip = @file_get_contents("http://networktools.nl/whois/$site");
               flush();
               $ip = @findit($getip,'<pre>','</pre>');
               return $ip;
               flush();
               }
               function findit($mytext,$starttag,$endtag) {
               $posLeft = @stripos($mytext,$starttag)+strlen($starttag);
               $posRight = @stripos($mytext,$endtag,$posLeft+1);
               return @substr($mytext,$posLeft,$posRight-$posLeft);
               flush();
               }
            ?>

            <form action="<?php $_PHP_SELF ?>" method="POST">
                <input class="form-control input-lg" type="text" name="site" placeholder="Masukan Domain"/><br><button class="btn btn-primary is-loading" type="submit" name="scan">Scan</button>
                <br><br>
            </form>

            <?php
               if(isset($_POST['scan']))
               {
               $site = @htmlentities($_POST['site']);
               if (empty($site)){die('Not Add IP');}
               $ip_port = @gethostbyname($site);
               echo '<pre><table id="ass" class="vert-align text-center">' . sws_domain_info($site) . '</textarea>';
               flush();
               }
            ?> 
            







  
  </div>
    </section>