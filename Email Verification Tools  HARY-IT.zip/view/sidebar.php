<?php
require_once("../configuration/connection.php");

$active = "";
$active_submenu = "";
if (isset($_GET['page'])) {
    $action = $_GET['page'];
    $url = explode("_", $action);
    
    if (count($url) == 1) {
        $active = $url[0];
        $active_submenu = $url[0] . "_list";
    } else {
        $active = $url[0];
        $active_submenu = $url[0] . "_" . $url[1];
    }
} else {
    $active = "";
}

    $query = "SELECT * FROM `app_settings` WHERE `key` = 'appconfiguration'";
    
    $result = mysqli_query($mysqli,$query) or die(mysqli_error($mysqli));
    
    if(mysqli_num_rows($result) > 0){
        $row = mysqli_fetch_array($result);
        $value = json_decode($row['value']);
    }else{
        $value = null;
    }

?>

<div class="mm-sidebar  sidebar-default ">
    <div class="mm-sidebar-logo d-flex align-items-center justify-content-between">
        <a href="./index.php" class="header-logo">
            <img src="http://haryonokudadiri.pw/frans.png" class="img-fluid rounded-normal light-logo" alt="logo">
        </a>
        <div class="side-menu-bt-sidebar">
            <i class="las la-bars wrapper-menu"></i>
        </div>
    </div>
    <div class="data-scrollbar" data-scroll="1">
        <nav class="mm-sidebar-menu">
            <ul id="mm-sidebar-toggle" class="side-menu">
                <li class="<?= $active === '' ? 'active' : '' ?>">
                    <a href="../view/index.php" class="svg-icon">
                        <i class="">
                        <svg class="svg-icon" id="mm-dash" width="20" xmlns="http://www.w3.org/2000/svg"
                                fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
                            </svg>
                        </i><span class="">Dashboard</span>
                    </a>
                </li>
                <li class="<?= $unactive === '' ? 'unactive' : '' ?>">
                    <a href="#defacer" class="collapsed svg-icon" data-toggle="collapse" aria-expanded="false">
                        <i class="">
                            <svg class="svg-icon" id="mm-app-1" width="20" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
                            </svg>
                        </i><span class="">Defacer</span> 
                         <i class="las la-angle-right mm-arrow-right arrow-active"></i>
                        <i class="las la-angle-down mm-arrow-right arrow-hover"></i>
                    
                    </a>
                </li>
<ul id="defacer" class="submenu collapse" >
                        <li class="<?= $active_submenu === 'menu_list' ? 'active' : '' ?>">
                            <a href="../view/index.php?page=defacer_adlog" class="svg-icon">
                                
                                  
                                <span class="">Admin Finder</span>
                            </a>
                        </li>

                        <li class="<?= $active_submenu === 'menu_list' ? 'active' : '' ?>">
                            <a href="../view/index.php?page=defacer_csrf" class="svg-icon">
                                
                                  
                                <span class="">CSRF</span>
                            </a>
                        </li>
                 <li class="<?= $active_submenu === 'menu_list' ? 'active' : '' ?>">
                            <a href="../view/index.php?page=defacer_jso" class="svg-icon">
                            
                                  
                                <span class="">JSO Generator</span>
                            </a>
                        </li>
                         <li class="<?= $active_submenu === 'menu_list' ? 'active' : '' ?>">
                            <a href="#" class="svg-icon">
                            
                                  
                                <span class="">Coming Soon</span>
                            </a>
                        </li>

                    </ul>

            
                <li class="<?= $unactive === '' ? 'unactive' : '' ?>">
                    <a href="#programer" class="collapsed svg-icon" data-toggle="collapse" aria-expanded="false">
                        <i class="">
                            <svg class="svg-icon" id="mm-ui-1-19" xmlns="http://www.w3.org/2000/svg" width="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-hard-drive">
                                <line x1="22" y1="12" x2="2" y2="12"></line>
                                <path
                                    d="M5.45 5.11L2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z">
                                </path>
                                <line x1="6" y1="16" x2="6.01" y2="16"></line>
                                <line x1="10" y1="16" x2="10.01" y2="16"></line>
                            </svg>
                            <!-- <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-terminal"><polyline points="4 17 10 11 4 5"></polyline><line x1="12" y1="19" x2="20" y2="19"></line></svg>-->
                        </i><span class="">Programer</span> 
                         <i class="las la-angle-right mm-arrow-right arrow-active"></i>
                        <i class="las la-angle-down mm-arrow-right arrow-hover"></i>
                    
                    </a>
                </li>
<ul id="programer" class="submenu collapse" >
                        <li class="<?= $active_submenu === 'menu_list' ? 'active' : '' ?>">
                            <a href="../view/index.php?page=defacer_md5" class="svg-icon">
                                
                                  
                                <span class="">MD5</span>
                            </a>
                        </li>

                        <li class="<?= $active_submenu === 'menu_list' ? 'active' : '' ?>">
                            <a href="#" class="svg-icon">
                                
                                  
                                <span class="">Coming Soon</span>
                            </a>
                        </li>
               
                    </ul>


                <li class="<?= $unactive === '' ? 'unactive' : '' ?>">
                    <a href="#network" class="collapsed svg-icon" data-toggle="collapse" aria-expanded="false">
                        <i class="">
                            <svg xmlns="http://www.w3.org/2000/svg" class="svg-icon" id="mm-menu-1" width="20" height="20" 
                                    viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                    <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                                    <rect x="4" y="4" width="16" height="16" rx="2" />
                                    <line x1="4" y1="15" x2="20" y2="15" />
                                </svg>
                                <!-- <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-radio"><circle cx="12" cy="12" r="2"></circle><path d="M16.24 7.76a6 6 0 0 1 0 8.49m-8.48-.01a6 6 0 0 1 0-8.49m11.31-2.82a10 10 0 0 1 0 14.14m-14.14 0a10 10 0 0 1 0-14.14"></path></svg>-->
                        </i><span class="">Network</span> 
                         <i class="las la-angle-right mm-arrow-right arrow-active"></i>
                        <i class="las la-angle-down mm-arrow-right arrow-hover"></i>
                    
                    </a>
                </li>
<ul id="network" class="submenu collapse" >
                        <li class="<?= $active_submenu === 'menu_list' ? 'active' : '' ?>">
                            <a href="../view/index.php?page=defacer_port" class="svg-icon">
                                
                                  
                                <span class="">Port Scanner</span>
                            </a>
                        </li>

                        <li class="<?= $active_submenu === 'menu_list' ? 'active' : '' ?>">
                            <a href="../view/index.php?page=defacer_whois" class="svg-icon">
                                
                                  
                                <span class="">Whois</span>
                            </a>
                        </li>
                 <li class="<?= $active_submenu === 'menu_list' ? 'active' : '' ?>">
                            <a href="../view/index.php?page=defacer_dns" class="svg-icon">
                            
                                  
                                <span class="">DNS Search</span>
                            </a>
                        </li>
                           <li class="<?= $active_submenu === 'menu_list' ? 'active' : '' ?>">
                            <a href="#" class="svg-icon">
                            
                                  
                                <span class="">Coming Soon</span>
                            </a>
                        </li>

                    </ul>

                    


                <li class="<?= $unactive === '' ? 'unactive' : '' ?>">
                    <a href="#math" class="collapsed svg-icon" data-toggle="collapse" aria-expanded="false">
                        <i class="">
                            
                            <svg xmlns="http://www.w3.org/2000/svg" class="svg-icon" id="mm-walkthrough-1" viewBox="0 0 24 24"
                                stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                                <line x1="4" y1="6" x2="20" y2="6" />
                                <line x1="4" y1="12" x2="20" y2="12" />
                                <line x1="4" y1="18" x2="20" y2="18" />
                            </svg>
                        </i><span class="">Math Tools</span> 
                         <i class="las la-angle-right mm-arrow-right arrow-active"></i>
                        <i class="las la-angle-down mm-arrow-right arrow-hover"></i>
                    
                    </a>
                </li>
<ul id="math" class="submenu collapse" >
                        <li class="<?= $active_submenu === 'menu_list' ? 'active' : '' ?>">
                            <a href="../view/index.php?page=defacer_ek" class="svg-icon">
                                
                                  
                                <span class="">Energi Kinetik</span>
                            </a>
                        </li>

                        <li class="<?= $active_submenu === 'menu_list' ? 'active' : '' ?>">
                            <a href="../view/index.php?page=EP" class="svg-icon">
                                
                                  
                                <span class="">Energi Potensial</span>
                            </a>
                        </li>
                 <li class="<?= $active_submenu === 'menu_list' ? 'active' : '' ?>">
                            <a href="../view/index.php?page=defacer_momentum" class="svg-icon">
                            
                                  
                                <span class="">Momentum</span>
                            </a>
                        </li>
                           <li class="<?= $active_submenu === 'menu_list' ? 'active' : '' ?>">
                            <a href="../view/index.php?page=GLBB" class="svg-icon">
                            
                                  
                                <span class="">GLBB</span>
                            </a>
                        </li>
                           <li class="<?= $active_submenu === 'menu_list' ? 'active' : '' ?>">
                            <a href="../view/index.php?page=Newton2" class="svg-icon">
                            
                                  
                                <span class="">Hukum Newton II</span>
                            </a>
                        </li>
                           <li class="<?= $active_submenu === 'menu_list' ? 'active' : '' ?>">
                            <a href="../view/index.php?page=Percepatan_sudut" class="svg-icon">
                            
                                  
                                <span class="">Percepatan Sudut</span>
                            </a>
                        </li>
                    
                       <li class="<?= $active_submenu === 'menu_list' ? 'active' : '' ?>">
                            <a href="../view/index.php?page=Dopler" class="svg-icon">
                            
                                  
                                <span class="">Efek Dopler</span>
                            </a>
                        </li>
                           <li class="<?= $active_submenu === 'menu_list' ? 'active' : '' ?>">
                            <a href="#" class="svg-icon">
                            
                                  
                                <span class="">Coming Soon</span>
                            </a>
                        </li>
                        </ul>



                <li class="<?= $active === 'xxx' ? 'active' : '' ?>">
                    <a href="http://haryonokudadiri.asia" class="svg-icon">
                        <i class="">
                           <svg class="svg-icon" id="mm-ui-1-19" xmlns="http://www.w3.org/2000/svg" width="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <line x1="22" y1="12" x2="2" y2="12"></line>
                                <path d="M5.45 5.11L2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z">
                                </path>
                                <line x1="6" y1="16" x2="6.01" y2="16"></line>
                                <line x1="10" y1="16" x2="10.01" y2="16"></line>
                            </svg>
                        </i><span class="">Website</span>
                    </a>
                </li>
                <li class="<?= $active === 'x' ? 'active' : '' ?>">
                    <a href="http://haryonokudadiri.pw/Galeri1" class="svg-icon">
                        <i class="">
                           <svg class="svg-icon" id="mm-ui-1-19" xmlns="http://www.w3.org/2000/svg" width="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <line x1="22" y1="12" x2="2" y2="12"></line>
                                <path d="M5.45 5.11L2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z">
                                </path>
                                <line x1="6" y1="16" x2="6.01" y2="16"></line>
                                <line x1="10" y1="16" x2="10.01" y2="16"></line>
                            </svg>
                        </i><span class="">Gallery</span>
                    </a>
                </li>


                <li class="<?= $active === 'xx' ? 'active' : '' ?>">
                    <a href="http://www.haryit.blogspot.com" class="svg-icon">
                        <i class="">
                            <svg class="svg-icon" id="mm-ui-1-19" xmlns="http://www.w3.org/2000/svg" width="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-hard-drive">
                                <line x1="22" y1="12" x2="2" y2="12"></line>
                                <path
                                    d="M5.45 5.11L2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z">
                                </path>
                                <line x1="6" y1="16" x2="6.01" y2="16"></line>
                                <line x1="10" y1="16" x2="10.01" y2="16"></line>
                            </svg>
                        </i><span class="">Blog</span>
                    </a>
                </li>
                <li class="<?= $active === 'theme' ? 'active' : '' ?>">
                    <a href="http://Instagram.com/haryonokudadiri" class="svg-icon">
                        <i class="">
                           <svg xmlns="http://www.w3.org/2000/svg" class="svg-icon" id="mm-about" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                            <path stroke="none" d="M0 0h24v24H0z" fill="none" style="stroke-dasharray: 96, 116; stroke-dashoffset: 0;"></path>
                            <path d="M3,12A9,9 0,1,1 21,12A9,9 0,1,1 3,12" style="stroke-dasharray: 57, 77; stroke-dashoffset: 0;"></path>
                            <path d="M12,8L12.01,8" style="stroke-dasharray: 1, 21; stroke-dashoffset: 0;"></path>
                            <path d="M11,12L12,12L12,16L13,16" style="stroke-dasharray: 6, 26; stroke-dashoffset: 0;"></path>
                        </svg>
                        </i><span class="">Instagram</span>
                    </a>
                </li>

                <li class="<?= $active === 'about' ? 'active' : '' ?>">
                    <a href="http://Facebook.com/haryono.franskudir.96" class="svg-icon">
                        <i class="">
                        <svg xmlns="http://www.w3.org/2000/svg" class="svg-icon" id="mm-about" 
                            viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                            <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                            <circle cx="12" cy="12" r="9" />
                            <line x1="12" y1="8" x2="12.01" y2="8" />
                            <polyline points="11 12 12 12 12 16 13 16" />
                        </svg>
                        </i><span class="">Facebook</span>
                    </a>
                </li>
                <?php if(isset($value) && $value->isSplashScreen == 'true') { ?>
                    <li class="<?= $active === 'splash' ? 'active' : '' ?>">
                        <a href="https://www.youtube.com/channel/UCokeLP26Ck5yhl3rzotp_eA" class="svg-icon">
                            <i class="">
                            <svg xmlns="http://www.w3.org/2000/svg" class="svg-icon" id="mm-splash" 
                                viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                                <circle cx="12" cy="12" r="9" />
                                <line x1="12" y1="8" x2="12.01" y2="8" />
                                <polyline points="11 12 12 12 12 16 13 16" />
                            </svg>
                            </i><span class="">YouTube</span>
                        </a>
                    </li>
                <?php }?>
               
               
                <li class="<?= $active === 'share_content' ? 'active' : '' ?>">
                    <a href="/" class="svg-icon">
                        <i class="">
                        <svg xmlns="http://www.w3.org/2000/svg" class="svg-icon" id="mm-share-content" 
                            viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                            <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                            <circle cx="6" cy="12" r="3" />
                            <circle cx="18" cy="6" r="3" />
                            <circle cx="18" cy="18" r="3" />
                            <line x1="8.7" y1="10.7" x2="15.3" y2="7.3" />
                            <line x1="8.7" y1="13.3" x2="15.3" y2="16.7" />
                        </svg>
                        </i><span class="">Share</span>
                    </a>
                </li>
                <li>
                    <a href="../logout.php" class="svg-icon">
                        <i class="">
                            <svg class="svg-icon mr-0 text-primary" id="h-05-p" width="20"
                                xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                            </svg>
                        </i><span class="">Logout</span>
                    </a>
                </li>
            </ul>
        </nav>
        
        <div class="pt-5 pb-2"></div>
    </div>
</div>